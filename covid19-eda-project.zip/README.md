# COVID-19 Exploratory Data Analysis

This project explores the COVID-19 dataset using Python. It covers data cleaning, visualization, and insight extraction to understand the spread and impact of the virus.

## Tools Used
- Python
- Pandas
- Matplotlib
- Seaborn

## Dataset
Data Source: [Kaggle COVID-19 Dataset](https://www.kaggle.com/imdevskp/corona-virus-report)

## Analysis Performed
- Data cleaning and preprocessing
- Trend analysis over time
- Visualizing daily vs total cases
- Country-wise comparisons
- Heatmaps of correlation

## How to Run
1. Clone the repo
2. Install dependencies: `pip install -r requirements.txt`
3. Open `notebooks/covid19_eda.ipynb` in Jupyter Notebook

## Author
Your Name
